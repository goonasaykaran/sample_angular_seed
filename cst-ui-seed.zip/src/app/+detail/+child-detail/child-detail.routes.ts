import { ChildDetailComponent } from './child-detail.component';

export const routes = [
  { path: '', component: ChildDetailComponent,  pathMatch: 'full' },
];
