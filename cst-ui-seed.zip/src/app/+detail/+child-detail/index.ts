export { ChildDetailModule } from './child-detail.module';
